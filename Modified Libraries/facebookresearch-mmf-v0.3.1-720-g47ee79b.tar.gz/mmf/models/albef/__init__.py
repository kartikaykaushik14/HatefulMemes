# Copyright (c) Facebook, Inc. and its affiliates.
import mmf.models.albef.vit  # noqa
