// Redirect for older pythia documentation
(function(l) {
  if (window.location.href.indexOf('readthedocs') !== -1) {
    window.location.href = "https://mmf.sh/api";
 }
}(window.location));
